"use client";

import {
  FormEvent,
  type RefObject,
  useEffect,
  useId,
  useMemo,
  useRef,
  useState,
  useTransition,
} from "react";
import type { Citation } from "@/lib/types";

type UiMessage = {
  id: string;
  role: "user" | "assistant";
  content: string;
  citations?: Citation[];
  warning?: string;
  refused?: boolean;
};

type Topic = { label: string; prompt: string };

type Props = {
  topics: Topic[];
};

const HELP_TOPICS: Topic[] = [
  { label: "Savings", prompt: "What is the minimum balance for a FinBase Digital Savings Account?" },
  { label: "UPI refunds", prompt: "My UPI transaction failed but money was deducted. When will I receive a refund?" },
  { label: "FD rates", prompt: "What is the interest rate for senior citizens on a 1-year Fixed Deposit?" },
  { label: "Video KYC", prompt: "What documents are required to complete Video KYC verification?" },
];

function CitationCard({ citation, index }: { citation: Citation; index: number }) {
  const pageLabel = citation.page > 0 ? ` · page ${citation.page}` : "";
  return (
    <article className="min-w-0 rounded-2xl border border-black/10 bg-white px-3.5 py-3">
      <div className="flex items-start gap-2.5">
        <span className="mt-0.5 inline-flex size-6 shrink-0 items-center justify-center rounded-full bg-[#C8E62B] text-[11px] font-bold text-[#0A0A0A]">
          {index + 1}
        </span>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-semibold text-[#0A0A0A]">{citation.title}</p>
          <p className="mt-0.5 text-[11px] font-medium text-[#5A6354]">
            FinBase policy guide{pageLabel}
          </p>
          <p className="mt-2 line-clamp-3 text-xs leading-relaxed text-[#3F463A]">
            {citation.excerpt}
          </p>
        </div>
      </div>
    </article>
  );
}

function CitationsBlock({ citations }: { citations: Citation[] }) {
  if (!citations.length) return null;
  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2">
        <span className="size-2.5 rounded-full bg-[#C8E62B] shadow-[0_0_0_4px_rgba(200,230,43,0.28)]" />
        <p className="text-[11px] font-bold uppercase tracking-[0.14em] text-[#0A0A0A]">
          Based on {citations.length === 1 ? "this policy" : "these policies"}
        </p>
      </div>
      <div className="grid gap-2">
        {citations.slice(0, 3).map((c, i) => (
          <CitationCard key={`${c.id}-${i}`} citation={c} index={i} />
        ))}
      </div>
    </div>
  );
}

function Composer({
  compact = false,
  placeholder,
  formId,
  input,
  pending,
  inputRef,
  onSubmit,
  onInput,
  onSend,
}: {
  compact?: boolean;
  placeholder: string;
  formId?: string;
  input: string;
  pending: boolean;
  inputRef: RefObject<HTMLTextAreaElement | null>;
  onSubmit: (e: FormEvent) => void;
  onInput: (value: string) => void;
  onSend: () => void;
}) {
  return (
    <form
      id={compact ? undefined : formId}
      onSubmit={onSubmit}
      className={`flex w-full items-end gap-2 rounded-[1.75rem] border-2 border-[#C8E62B]/70 bg-white px-3 py-2 shadow-[0_18px_50px_rgba(20,30,10,0.10)] ${
        compact ? "" : "sm:px-4 sm:py-3"
      }`}
    >
      <label className="sr-only" htmlFor={compact ? "chat-input-compact" : "chat-input"}>
        Message
      </label>
      <textarea
        id={compact ? "chat-input-compact" : "chat-input"}
        ref={inputRef}
        rows={compact ? 1 : 2}
        value={input}
        onChange={(e) => onInput(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            onSend();
          }
        }}
        placeholder={placeholder}
        className="max-h-32 min-h-11 flex-1 resize-none bg-transparent py-2.5 text-sm leading-relaxed text-[#0A0A0A] outline-none placeholder:text-[#6B7464]"
      />
      <button
        type="submit"
        disabled={pending || !input.trim()}
        aria-label="Send message"
        className="mb-0.5 inline-flex size-11 shrink-0 items-center justify-center rounded-full bg-[#0A0A0A] text-white transition hover:bg-[#1C1C1C] disabled:cursor-not-allowed disabled:opacity-35"
      >
        <svg viewBox="0 0 24 24" className="size-4" fill="none" aria-hidden>
          <path
            d="M5 12h14M13 6l6 6-6 6"
            stroke="currentColor"
            strokeWidth="2.2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </button>
    </form>
  );
}

export function ChatApp({ topics }: Props) {
  const topicChips = topics.length ? topics : HELP_TOPICS;
  const [messages, setMessages] = useState<UiMessage[]>([]);
  const [input, setInput] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [pending, startTransition] = useTransition();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const formId = useId();

  const hasChat = messages.length > 0;
  const topicTitle = useMemo(() => {
    const firstUser = messages.find((m) => m.role === "user");
    if (!firstUser) return "Help";
    return firstUser.content.length > 56
      ? `${firstUser.content.slice(0, 56)}…`
      : firstUser.content;
  }, [messages]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, pending]);

  async function send(text: string) {
    const trimmed = text.trim();
    if (!trimmed || pending) return;

    setError(null);
    setInput("");
    setSidebarOpen(false);

    const userMsg: UiMessage = {
      id: `u-${Date.now()}`,
      role: "user",
      content: trimmed,
    };
    const nextHistory = [...messages, userMsg];
    setMessages(nextHistory);

    startTransition(async () => {
      try {
        const res = await fetch("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            message: trimmed,
            history: nextHistory
              .slice(-6)
              .map((m) => ({ role: m.role, content: m.content })),
          }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Chat request failed");

        setMessages((prev) => [
          ...prev,
          {
            id: `a-${Date.now()}`,
            role: "assistant",
            content: data.answer,
            citations: Array.isArray(data.citations) ? data.citations : [],
            warning: data.warning,
            refused: data.refused,
          },
        ]);
      } catch (err) {
        const msg = err instanceof Error ? err.message : "Something went wrong";
        setError(msg);
        setMessages((prev) => [
          ...prev,
          {
            id: `a-${Date.now()}`,
            role: "assistant",
            content:
              "Sorry — I could not complete that reply. Please try again in a moment.",
            citations: [],
            refused: true,
          },
        ]);
      } finally {
        inputRef.current?.focus();
      }
    });
  }

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    void send(input);
  }

  function startFresh() {
    setMessages([]);
    setError(null);
    setSidebarOpen(false);
  }

  return (
    <div
      className="atmosphere relative flex min-h-screen overflow-hidden"
      style={{ backgroundColor: "#F3F5EF", color: "#0A0A0A" }}
    >
      <div
        aria-hidden
        className="hero-orb pointer-events-none absolute -left-24 top-10 size-80 rounded-full blur-3xl"
        style={{ background: "rgba(200,230,43,0.35)" }}
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -right-16 bottom-0 size-96 rounded-full blur-3xl"
        style={{ background: "rgba(197,214,180,0.45)" }}
      />

      <header className="fixed inset-x-0 top-0 z-30 flex items-center justify-between bg-[#C8E62B] px-4 py-3 lg:hidden">
        <button
          type="button"
          className="inline-flex min-h-11 min-w-11 items-center justify-center rounded-full bg-black/10 text-[#0A0A0A]"
          onClick={() => setSidebarOpen(true)}
          aria-label="Open menu"
        >
          ☰
        </button>
        <div className="text-center">
          <p className="font-[family-name:var(--font-display)] text-lg font-semibold tracking-tight text-[#0A0A0A]">
            FinBase
          </p>
          <p className="text-[11px] font-medium text-[#0A0A0A]/70">
            {hasChat ? topicTitle : "Customer support"}
          </p>
        </div>
        <span className="inline-flex size-11 items-center justify-center rounded-full bg-[#0A0A0A] text-xs font-bold text-[#C8E62B]">
          FB
        </span>
      </header>

      {sidebarOpen && (
        <button
          type="button"
          className="fixed inset-0 z-40 bg-black/35 lg:hidden"
          aria-label="Close sidebar"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <aside
        className={`fixed inset-y-0 left-0 z-50 flex w-[18.5rem] flex-col border-r border-black/10 bg-[#F7F9F3] p-4 transition-transform lg:static lg:z-10 lg:translate-x-0 lg:border-0 lg:bg-transparent lg:p-5 ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="hidden items-center gap-3 lg:flex">
          <span className="inline-flex size-11 items-center justify-center rounded-2xl bg-[#C8E62B] font-[family-name:var(--font-display)] text-lg font-bold text-[#0A0A0A] shadow-[0_8px_24px_rgba(200,230,43,0.45)]">
            F
          </span>
          <div>
            <p className="font-[family-name:var(--font-display)] text-xl font-semibold tracking-tight text-[#0A0A0A]">
              FinBase
            </p>
            <p className="text-xs font-medium text-[#5A6354]">Customer support</p>
          </div>
        </div>

        <div className="fb-card mt-5 rounded-[1.5rem] p-4 lg:mt-8">
          <p className="text-sm font-semibold text-[#0A0A0A]">Ask about your banking</p>
          <p className="mt-1 text-xs leading-relaxed text-[#5A6354]">
            Savings, payments, cards, deposits, loans, and KYC — answered from FinBase
            policies.
          </p>
        </div>

        <div className="mt-6 flex items-center justify-between px-1">
          <p className="text-xs font-bold uppercase tracking-[0.16em] text-[#5A6354]">
            This chat
          </p>
          <button
            type="button"
            className="rounded-full bg-[#C8E62B] px-3 py-1 text-xs font-bold text-[#0A0A0A]"
            onClick={startFresh}
          >
            New
          </button>
        </div>

        <div className="mt-3 flex-1 space-y-2 overflow-y-auto scrollbar-thin pr-1">
          {hasChat ? (
            <div className="flex w-full items-start gap-3 rounded-[1.35rem] bg-[#0A0A0A] px-3.5 py-3 text-left text-white shadow-[0_12px_28px_rgba(0,0,0,0.18)]">
              <span className="mt-1.5 size-2.5 shrink-0 rounded-full bg-[#C8E62B]" />
              <span className="min-w-0">
                <span className="block truncate text-sm font-semibold">{topicTitle}</span>
                <span className="mt-0.5 block truncate text-xs text-white/70">
                  {messages.filter((m) => m.role === "assistant").at(-1)?.content.slice(0, 64) ||
                    "Waiting for reply…"}
                </span>
              </span>
            </div>
          ) : (
            <p className="px-1 text-sm text-[#5A6354]">
              No conversation yet. Ask a question to get started.
            </p>
          )}
        </div>

        <div className="mt-4 rounded-[1.35rem] border border-black/10 bg-white p-3 text-[11px] leading-relaxed text-[#5A6354]">
          Answers come from FinBase product policies. For account changes or fraud, contact a
          human agent.
        </div>
      </aside>

      <main className="relative z-10 flex min-w-0 flex-1 flex-col pt-[4.25rem] lg:pt-0">
        {!hasChat ? (
          <section className="relative flex flex-1 flex-col items-center justify-center px-4 py-10 sm:px-8">
            <div className="w-full max-w-2xl animate-[fadeUp_0.55s_ease-out] text-center">
              <p className="inline-flex items-center gap-2 rounded-full bg-[#C8E62B]/35 px-3 py-1 text-xs font-bold uppercase tracking-[0.18em] text-[#0A0A0A]">
                <span className="size-2 rounded-full bg-[#C8E62B]" />
                FinBase Assist
              </p>
              <h1 className="mt-4 font-[family-name:var(--font-display)] text-[clamp(2.1rem,5vw,3.4rem)] font-semibold leading-[1.08] tracking-tight text-[#0A0A0A]">
                How can we help?
              </h1>
              <p className="mx-auto mt-4 max-w-lg text-sm leading-relaxed text-[#5A6354] sm:text-base">
                Get clear answers on balances, refunds, cards, deposits, loans, and verification —
                grounded in FinBase policies.
              </p>

              <div className="mt-8">
                <Composer
                  placeholder="Ask about your account, a payment, or a product…"
                  formId={formId}
                  input={input}
                  pending={pending}
                  inputRef={inputRef}
                  onSubmit={onSubmit}
                  onInput={setInput}
                  onSend={() => void send(input)}
                />
              </div>

              <div className="mt-5 flex flex-wrap justify-center gap-2">
                {topicChips.slice(0, 6).map((t) => (
                  <button
                    key={t.label}
                    type="button"
                    onClick={() => void send(t.prompt)}
                    className="min-h-11 rounded-full border border-black/10 bg-white px-4 py-2 text-sm font-medium text-[#0A0A0A] shadow-sm transition hover:border-[#C8E62B] hover:bg-[#F8FAF4]"
                  >
                    {t.label}
                  </button>
                ))}
              </div>
            </div>
          </section>
        ) : (
          <>
            <div className="hidden items-start justify-between gap-4 border-b border-black/8 px-6 py-5 lg:flex xl:px-8">
              <div>
                <h1 className="font-[family-name:var(--font-display)] text-2xl font-semibold tracking-tight text-[#0A0A0A] xl:text-3xl">
                  {topicTitle}
                </h1>
                <div className="mt-2 flex flex-wrap items-center gap-2 text-sm text-[#5A6354]">
                  <span className="inline-flex items-center gap-1.5 rounded-full border border-black/8 bg-white px-2.5 py-1 text-xs font-bold text-[#0A0A0A] shadow-sm">
                    <span className="size-2 animate-[softPulse_1.8s_ease-in-out_infinite] rounded-full bg-[#C8E62B]" />
                    Support online
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={startFresh}
                className="min-h-11 rounded-full border border-black/10 bg-white px-4 text-sm font-semibold text-[#0A0A0A] hover:bg-[#E5EADF]"
              >
                New chat
              </button>
            </div>

            <div className="flex-1 space-y-4 overflow-y-auto px-4 py-4 scrollbar-thin sm:px-6 xl:px-8">
              {messages.map((m) => (
                <div
                  key={m.id}
                  className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[min(100%,42rem)] ${
                      m.role === "user" ? "w-auto" : "w-full"
                    }`}
                  >
                    <div
                      className={`rounded-[1.6rem] px-4 py-3 text-sm leading-relaxed sm:px-5 sm:py-3.5 ${
                        m.role === "user"
                          ? "rounded-br-md bg-white text-[#0A0A0A] shadow-[0_10px_28px_rgba(20,30,10,0.08)]"
                          : "rounded-bl-md bg-[#0A0A0A] text-white shadow-[0_14px_34px_rgba(0,0,0,0.16)]"
                      }`}
                    >
                      <p className="whitespace-pre-wrap">{m.content}</p>
                      {m.warning && (
                        <p
                          className={`mt-2 text-xs ${
                            m.role === "user" ? "text-[#9A6B00]" : "text-[#C8E62B]"
                          }`}
                        >
                          {m.warning}
                        </p>
                      )}
                    </div>

                    {m.role === "assistant" &&
                      m.citations &&
                      m.citations.length > 0 && (
                        <div className="mt-2 rounded-[1.35rem] border border-black/10 bg-[#EEF2EA] p-3 sm:p-3.5">
                          <CitationsBlock citations={m.citations} />
                        </div>
                      )}
                  </div>
                </div>
              ))}

              {pending && (
                <div className="flex justify-start">
                  <div className="inline-flex items-center gap-2 rounded-[1.4rem] rounded-bl-md bg-[#0A0A0A] px-4 py-3 text-sm text-white/80">
                    <span className="flex gap-1">
                      <span className="size-1.5 animate-pulse rounded-full bg-[#C8E62B]" />
                      <span className="size-1.5 animate-pulse rounded-full bg-[#C8E62B] [animation-delay:120ms]" />
                      <span className="size-1.5 animate-pulse rounded-full bg-[#C8E62B] [animation-delay:240ms]" />
                    </span>
                    Looking up your answer…
                  </div>
                </div>
              )}
              <div ref={bottomRef} />
            </div>

            <div className="border-t border-black/8 bg-[#F3F5EF]/95 px-4 py-3 backdrop-blur sm:px-6 xl:px-8">
              {error && (
                <p className="mb-2 text-sm text-rose-700" role="alert">
                  {error}
                </p>
              )}
              <div className="mb-3 flex gap-2 overflow-x-auto pb-1 scrollbar-thin">
                {HELP_TOPICS.map((a) => (
                  <button
                    key={a.label}
                    type="button"
                    onClick={() => void send(a.prompt)}
                    className="min-h-11 shrink-0 rounded-full border border-black/10 bg-white px-4 text-sm font-semibold text-[#0A0A0A] hover:border-[#C8E62B] hover:bg-[#F8FAF4]"
                  >
                    {a.label}
                  </button>
                ))}
              </div>
              <Composer
                compact
                placeholder="Ask a follow-up…"
                input={input}
                pending={pending}
                inputRef={inputRef}
                onSubmit={onSubmit}
                onInput={setInput}
                onSend={() => void send(input)}
              />
            </div>
          </>
        )}
      </main>

      <aside className="relative z-10 hidden w-[19rem] shrink-0 flex-col gap-4 border-l border-black/8 bg-transparent p-5 xl:flex">
        <div className="rounded-[1.6rem] bg-[#0A0A0A] p-5 text-white shadow-[0_18px_40px_rgba(0,0,0,0.18)]">
          <p className="text-xs font-bold uppercase tracking-[0.16em] text-[#C8E62B]">
            Popular topics
          </p>
          <p className="mt-2 font-[family-name:var(--font-display)] text-xl font-semibold leading-snug text-white">
            Start with what you need.
          </p>
          <div className="mt-4 space-y-2">
            {HELP_TOPICS.map((a) => (
              <button
                key={a.label}
                type="button"
                onClick={() => void send(a.prompt)}
                className="flex min-h-11 w-full items-center justify-between rounded-full bg-white/10 px-4 text-left text-sm font-semibold text-white transition hover:bg-white/15"
              >
                <span>{a.label}</span>
                <span className="text-[#C8E62B]">→</span>
              </button>
            ))}
          </div>
        </div>

        <div className="fb-card rounded-[1.6rem] p-5">
          <p className="text-xs font-bold uppercase tracking-[0.16em] text-[#5A6354]">
            Need a person?
          </p>
          <p className="mt-2 text-sm leading-relaxed text-[#0A0A0A]">
            For disputes, fraud, or changes to your account, a support agent should take over.
          </p>
          <a
            href="mailto:support@finbase.example?subject=Customer%20support"
            className="mt-4 inline-flex min-h-11 w-full items-center justify-center rounded-full bg-[#C8E62B] px-4 text-sm font-bold text-[#0A0A0A] transition hover:bg-[#B4D11F]"
          >
            Email support
          </a>
        </div>

        {hasChat && (
          <div className="rounded-[1.6rem] border border-black/10 bg-[#EEF2EA] p-4">
            <p className="text-xs font-bold uppercase tracking-[0.16em] text-[#5A6354]">
              Sources used
            </p>
            <div className="mt-3">
              <CitationsBlock
                citations={
                  messages
                    .filter((m) => m.role === "assistant" && m.citations?.length)
                    .at(-1)?.citations || []
                }
              />
            </div>
          </div>
        )}
      </aside>
    </div>
  );
}
