import { readFileSync } from "fs";
import path from "path";
import type { FaqItem, KnowledgeChunk } from "./types";

let chunksCache: KnowledgeChunk[] | null = null;
let faqsCache: FaqItem[] | null = null;

function dataPath(...parts: string[]) {
  return path.join(process.cwd(), "data", "knowledge", ...parts);
}

export function getChunks(): KnowledgeChunk[] {
  if (!chunksCache) {
    chunksCache = JSON.parse(
      readFileSync(dataPath("chunks.json"), "utf8"),
    ) as KnowledgeChunk[];
  }
  return chunksCache;
}

export function getFaqs(): FaqItem[] {
  if (!faqsCache) {
    faqsCache = JSON.parse(
      readFileSync(dataPath("faqs.json"), "utf8"),
    ) as FaqItem[];
  }
  return faqsCache;
}

/** Short topic chips for the empty state — not sample FAQ dumps. */
export function getStarterTopics(
  limit = 6,
): { label: string; prompt: string }[] {
  const topics = [
    {
      label: "Savings balance",
      prompt: "What is the minimum balance for a FinBase Digital Savings Account?",
    },
    {
      label: "UPI refunds",
      prompt:
        "My UPI transaction failed but money was deducted. When will I receive a refund?",
    },
    {
      label: "FD interest",
      prompt:
        "What is the interest rate for senior citizens on a 1-year Fixed Deposit?",
    },
    {
      label: "Credit cards",
      prompt: "What are the key fees and limits on FinBase credit cards?",
    },
    {
      label: "Personal loans",
      prompt: "What are the eligibility requirements for a FinBase personal loan?",
    },
    {
      label: "Video KYC",
      prompt: "What documents are required to complete Video KYC verification?",
    },
  ];
  return topics.slice(0, limit);
}

/** @deprecated use getStarterTopics */
export function getStarterQuestions(limit = 6): string[] {
  return getStarterTopics(limit).map((t) => t.prompt);
}
