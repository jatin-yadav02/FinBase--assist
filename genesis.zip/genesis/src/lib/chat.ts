import {
  buildFallbackAnswer,
  contentTokens,
  isLowConfidence,
  retrieveContext,
} from "./retrieve";
import {
  OPENROUTER_MODEL,
  createOpenRouterClient,
  getOpenRouterApiKey,
} from "./openrouter";
import { customerizeText, customerWarning } from "./customer-copy";
import type { ChatMessage, ChatResponse, Citation } from "./types";

const SYSTEM_PROMPT = `You are FinBase Assist, a customer-support agent for FinBase.

Rules:
- Answer ONLY using the CONTEXT excerpts. Every number, fee, rate, and timeline must appear in CONTEXT.
- If CONTEXT does not answer the question, reply with exactly: I could not find that in FinBase’s policy documents.
- Do not stitch facts from unrelated policies into one answer.
- Write one or two short sentences in plain language, then a source line.
- Shape:
  <answer sentence>

  Source: <policy title — section, taken from the context header>
- Do not mention internal codes, file names, applicability notes, verification notes, billing engine codes, tier codes, product codes, or how this system works.
- Do not claim you can freeze cards, file disputes, or change limits. Point the customer to the FinBase app or a human agent when an action is required.
- Currency is INR (₹).`;

function formatContext(citations: Citation[]): string {
  return citations
    .map(
      (c, i) =>
        `[#${i + 1}] ${c.source}${c.page ? ` (page ${c.page})` : ""}\n${customerizeText(c.excerpt)}`,
    )
    .join("\n\n");
}

function retrievalQuery(question: string, history: ChatMessage[]): string {
  const tokens = contentTokens(question);
  if (tokens.length === 0 || tokens.length >= 3) return question;
  const prev = [...history]
    .reverse()
    .find((message) => message.role === "user" && message.content.trim() !== question);
  return prev ? `${prev.content} ${question}` : question;
}

function priorHistory(history: ChatMessage[], question: string): ChatMessage[] {
  const last = history[history.length - 1];
  if (last?.role === "user" && last.content.trim() === question) {
    return history.slice(0, -1);
  }
  return history;
}

function polishResponse(result: ChatResponse): ChatResponse {
  return {
    ...result,
    answer: customerizeText(result.answer),
    warning: customerWarning(result.warning),
    citations: result.citations.map((c) => ({
      ...c,
      excerpt: customerizeText(c.excerpt),
      docCode: "",
    })),
  };
}

export async function answerQuestion(
  question: string,
  history: ChatMessage[] = [],
): Promise<ChatResponse> {
  const trimmed = question.trim();
  if (!trimmed) {
    return polishResponse({
      answer: "Please enter a question about FinBase products or policies.",
      citations: [],
      mode: "retrieval-fallback",
      refused: true,
    });
  }

  const citations = retrieveContext(retrievalQuery(trimmed, history), 3);

  if (isLowConfidence(citations)) {
    const fallback = buildFallbackAnswer(trimmed, citations);
    return polishResponse({
      answer: fallback.answer,
      citations: [],
      mode: "retrieval-fallback",
      refused: fallback.refused,
    });
  }

  const apiKey = getOpenRouterApiKey();
  if (!apiKey) {
    const fallback = buildFallbackAnswer(trimmed, citations);
    return polishResponse({
      answer: fallback.answer,
      citations,
      mode: "retrieval-fallback",
      refused: fallback.refused,
    });
  }

  const client = createOpenRouterClient();
  const context = formatContext(citations);
  const messages: { role: "system" | "user" | "assistant"; content: string }[] =
    [
      { role: "system", content: SYSTEM_PROMPT },
      {
        role: "system",
        content: `CONTEXT:\n${context}`,
      },
      ...priorHistory(history, trimmed).slice(-6).map((m) => ({
        role: m.role,
        content: m.content,
      })),
      { role: "user", content: trimmed },
    ];

  try {
    const completion = await client.chat.completions.create({
      model: OPENROUTER_MODEL,
      temperature: 0.2,
      messages,
    });

    const answer = completion.choices[0]?.message?.content?.trim() || "";
    if (!answer) {
      const fallback = buildFallbackAnswer(trimmed, citations);
      return polishResponse({
        answer: fallback.answer,
        citations: fallback.refused ? [] : citations.slice(0, 1),
        mode: "retrieval-fallback",
        refused: fallback.refused,
      });
    }

    const refused = /could not find|don't have|do not have|outside|not in (the )?finbase/i.test(
      answer,
    );
    return polishResponse({
      answer,
      citations: refused ? [] : citations,
      mode: "llm",
      refused,
    });
  } catch (err) {
    console.error(
      "FinBase Assist model call failed:",
      err instanceof Error ? err.message : err,
    );
    const fallback = buildFallbackAnswer(trimmed, citations);
    return polishResponse({
      answer: fallback.answer,
      citations: fallback.refused ? [] : citations.slice(0, 2),
      mode: "retrieval-fallback",
      refused: fallback.refused,
    });
  }
}
