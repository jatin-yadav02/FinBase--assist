import OpenAI from "openai";

export const OPENROUTER_MODEL =
  process.env.OPENROUTER_MODEL?.trim() || "z-ai/glm-5.3-flash";

export function getOpenRouterApiKey(): string | undefined {
  const key =
    process.env.OPENROUTER_API_KEY?.trim() ||
    process.env.OPEN_ROUTER_API_KEY?.trim();
  return key || undefined;
}

export function createOpenRouterClient() {
  const apiKey = getOpenRouterApiKey();
  if (!apiKey) {
    throw new Error("OPENROUTER_API_KEY is not set");
  }

  return new OpenAI({
    apiKey,
    baseURL: "https://openrouter.ai/api/v1",
    defaultHeaders: {
      "HTTP-Referer": "http://localhost:4317",
      "X-OpenRouter-Title": "FinBase Customer Support",
    },
  });
}
