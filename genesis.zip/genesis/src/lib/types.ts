export type KnowledgeChunk = {
  id: string;
  source: string;
  title: string;
  docCode: string;
  category: string;
  page: number;
  text: string;
};

export type FaqItem = {
  id: string;
  question: string;
  answer: string;
  source: string;
  title: string;
  category: string;
};

export type Citation = {
  id: string;
  title: string;
  source: string;
  docCode: string;
  page: number;
  excerpt: string;
  score: number;
};

export type ChatMessage = {
  role: "user" | "assistant";
  content: string;
};

export type ChatResponse = {
  answer: string;
  citations: Citation[];
  mode: "llm" | "retrieval-fallback";
  refused: boolean;
  warning?: string;
};
