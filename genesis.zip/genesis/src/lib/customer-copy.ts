/** Customer-facing copy helpers — hide corpus filenames and internal jargon. */

const INTERNAL_LABEL =
  /^(applicability|verification note|verification engine|verification reference|exception criteria|escalation sla|billing engine code|tier scope|switch route|reconciliation code|dispute turnaround time|account classification|statement proof|support resolution sla|instrument category|risk-o-meter rating|tax implication|document code|issuing authority|classification|effective date|prerequisites(?: for the customer)?|operational inquiry)\b/i;

const NOISE_PHRASES = [
  /\[Reference[^\]]*\]\.?/gi,
  /Under Section \d+(?:\.\d+)?,?\s*/gi,
  /Document Code:\s*[A-Z0-9-]+/gi,
  /Issuing Authority:[^\n.]+/gi,
  /Classification:[^\n.]+/gi,
  /Effective Date:[^\n.]+/gi,
  /\b(?:loan tier code|product code|clause|billing engine code)\s+[A-Z0-9-]+\b/gi,
  /\b(?:PL|SAV|PAY|WLT|KYC|WLTH|CC)-[A-Z0-9-]+\b/gi,
  /_?Retrieval fallback[^.]*\.?_?/gi,
  /OPENROUTER_API_KEY[^.]*\.?/gi,
  /Fell back to retrieval[^.]*\.?/gi,
  /no LLM[^.]*\.?/gi,
  /GLM 5\.3 Flash[^.]*\.?/gi,
  /\*\*/g,
];

const CATEGORY_LABELS: Record<string, string> = {
  wealth: "Fixed deposits & wealth",
  payments: "Payments & UPI",
  cards: "Credit cards",
  savings: "Savings accounts",
  loans: "Personal loans",
  kyc: "KYC & security",
  general: "FinBase policy",
};

export function categoryLabel(category: string): string {
  return CATEGORY_LABELS[category] || "FinBase policy";
}

export function friendlySourceLabel(source: string, title?: string): string {
  if (title?.trim()) return title.trim();
  const base = source.replace(/^sample_\d+\.pdf$/i, "").replace(/\.pdf$/i, "");
  return base || "FinBase policy guide";
}

function isInternalField(part: string): boolean {
  return INTERNAL_LABEL.test(part.trim());
}

/** Strip assignment-corpus boilerplate from policy text for customers. */
export function customerizeText(text: string): string {
  const pieces = text
    .replace(/■/g, "₹")
    .split(/\u007f|\u0007/)
    .map((part) => part.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, " ").trim())
    .filter((part) => part && !isInternalField(part));

  let out = pieces.join(" ");
  out = out.replace(
    /\s*(?:Applicability|Verification note|Verification engine|Verification reference|Exception criteria|Escalation SLA|Billing Engine Code|Tier Scope|Switch Route|Reconciliation code|Dispute turnaround time|Account Classification|Statement proof|Support resolution SLA|Instrument Category|Risk-o-meter Rating|Tax implication)\s*:[\s\S]*$/i,
    "",
  );
  for (const re of NOISE_PHRASES) {
    out = out.replace(re, "");
  }
  out = out.replace(/[·•]/g, " ");
  out = out.replace(/[^\S\n]+/g, " ");
  out = out.replace(/ *\n */g, "\n");
  out = out.replace(/\n{3,}/g, "\n\n").trim();
  return out;
}

export function policySection(text: string): string | undefined {
  const clean = customerizeText(text);
  const match = clean.match(/Section\s+\d+(?:\.\d+)?(?=\s|,|\.|\)|$)/i);
  if (!match) return undefined;
  if (/section\s+194/i.test(match[0])) return undefined;
  return match[0].replace(/section/i, "Section");
}

export function asCustomerSentence(text: string): string {
  let sentence = customerizeText(text).replace(/^\d+\)\s*/, "").replace(/\s+/g, " ").trim();
  if (!sentence) return "";
  sentence = sentence.charAt(0).toUpperCase() + sentence.slice(1);
  if (!/[.!?]$/.test(sentence)) sentence += ".";
  return sentence;
}

export function customerWarning(warning?: string): string | undefined {
  if (!warning) return undefined;
  if (/OPENROUTER|retrieval-only|retrieval fallback|LLM call failed|no LLM/i.test(warning)) {
    return undefined;
  }
  return warning;
}
