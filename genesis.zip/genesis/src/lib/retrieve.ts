import MiniSearch from "minisearch";
import {
  asCustomerSentence,
  customerizeText,
  friendlySourceLabel,
  policySection,
} from "./customer-copy";
import { getChunks, getFaqs } from "./knowledge";
import type { Citation, FaqItem, KnowledgeChunk } from "./types";

const STOPWORDS = new Set([
  "a", "an", "the", "i", "me", "my", "we", "our", "you", "your", "it", "its",
  "this", "that", "these", "those", "is", "am", "are", "was", "were", "be",
  "been", "being", "do", "does", "did", "doing", "have", "has", "had", "having",
  "to", "of", "for", "on", "in", "at", "by", "from", "with", "as", "into",
  "over", "after", "before", "and", "or", "but", "if", "then", "so", "than",
  "not", "no", "nor", "what", "which", "who", "whom", "whose", "how", "when",
  "where", "why", "can", "could", "would", "should", "will", "shall", "may",
  "might", "must", "please", "hi", "hello", "hey", "thanks", "thank", "ok",
  "okay", "yes", "yeah", "yep", "there", "here", "just", "like", "want",
  "need", "dont", "don't", "im", "i'm", "know", "ask", "about", "tell",
  "something", "anything", "everything", "hiya", "good", "morning",
  "afternoon", "evening",
]);

const GENERIC = new Set([
  "finbase", "policy", "policies", "customer", "customers", "account",
  "accounts", "section", "product", "products", "bank", "banking",
]);

export function contentTokens(query: string): string[] {
  return query
    .toLowerCase()
    .replace(/['’]/g, "")
    .replace(/[^a-z0-9]+/g, " ")
    .split(/\s+/)
    .filter((token) => token.length >= 2 && !STOPWORDS.has(token));
}

function distinctiveTokens(tokens: string[]): string[] {
  const specific = tokens.filter((token) => !GENERIC.has(token));
  return specific.length ? specific : tokens;
}

function termOverlap(text: string, tokens: string[]): number {
  if (!tokens.length) return 0;
  const hay = text.toLowerCase();
  const hits = tokens.filter((token) => hay.includes(token)).length;
  return hits / tokens.length;
}

function minOverlap(tokenCount: number): number {
  if (tokenCount <= 2) return 1;
  if (tokenCount === 3) return 2 / 3;
  return 0.5;
}

function isContentsPage(text: string): boolean {
  return /table of contents/i.test(text) || (text.match(/section\s+\d+/gi)?.length ?? 0) >= 4;
}

type IndexedChunk = KnowledgeChunk & { searchText: string };

let index: MiniSearch<IndexedChunk> | null = null;
let faqIndex: MiniSearch<FaqItem> | null = null;

function getChunkIndex() {
  if (index) return index;
  const docs = getChunks().map((c) => ({
    ...c,
    searchText: `${c.title} ${c.docCode} ${c.category} ${c.text}`,
  }));
  index = new MiniSearch<IndexedChunk>({
    fields: ["searchText", "title", "category"],
    storeFields: [
      "id",
      "source",
      "title",
      "docCode",
      "category",
      "page",
      "text",
    ],
    searchOptions: {
      boost: { title: 2, category: 1.5 },
      fuzzy: 0.15,
      prefix: true,
    },
  });
  index.addAll(docs);
  return index;
}

function getFaqIndex() {
  if (faqIndex) return faqIndex;
  faqIndex = new MiniSearch<FaqItem>({
    fields: ["question", "answer", "category", "title"],
    storeFields: [
      "id",
      "question",
      "answer",
      "source",
      "title",
      "category",
    ],
    searchOptions: { boost: { question: 3 }, fuzzy: 0.2, prefix: true },
  });
  faqIndex.addAll(getFaqs());
  return faqIndex;
}

const NOT_FOUND =
  "I could not find that in FinBase’s policy documents. I can help with savings, UPI and refunds, credit cards, fixed deposits, personal loans, and KYC.";

const HELP =
  "Ask a specific FinBase question and I’ll answer from the policy guides. For example: savings balance, UPI refunds, card fees, fixed-deposit rates, personal-loan foreclosure, or Video KYC documents.";

type Ranked = {
  citation: Citation;
  overlap: number;
  faq: boolean;
};

function excerptFrom(raw: string): string {
  const clean = customerizeText(raw).replace(/\s+/g, " ").trim();
  if (clean.length <= 420) return clean;
  const cut = clean.slice(0, 420);
  const stop = Math.max(cut.lastIndexOf(". "), cut.lastIndexOf("? "));
  return (stop > 160 ? cut.slice(0, stop + 1) : cut).trim();
}

export function retrieveContext(query: string, limit = 3): Citation[] {
  const tokens = distinctiveTokens(contentTokens(query));
  if (!tokens.length) return [];

  const q = tokens.join(" ");
  const needed = minOverlap(tokens.length);
  const searchOpts = { prefix: true, fuzzy: 0.1 as const };
  const faqHits = getFaqIndex().search(q, { ...searchOpts, combineWith: "OR" });
  const strictChunks = getChunkIndex().search(q, { ...searchOpts, combineWith: "AND" });
  const chunkHits = strictChunks.length
    ? strictChunks
    : getChunkIndex().search(q, { ...searchOpts, combineWith: "OR" });

  const ranked: Ranked[] = [];

  for (const hit of faqHits) {
    const question = String(hit.question);
    const answer = String(hit.answer);
    const overlap = termOverlap(`${question} ${answer}`, tokens);
    if (overlap < needed) continue;
    const excerpt = asCustomerSentence(excerptFrom(answer));
    if (excerpt.length < 40) continue;
    const title = String(hit.title);
    const section = policySection(excerpt);
    ranked.push({
      faq: true,
      overlap,
      citation: {
        id: String(hit.id),
        title,
        source: section ? `${title} — ${section}` : friendlySourceLabel(String(hit.source), title),
        docCode: "",
        page: 0,
        excerpt,
        score: hit.score,
      },
    });
  }

  for (const hit of chunkHits) {
    const text = String(hit.text);
    if (isContentsPage(text)) continue;
    const title = String(hit.title);
    const overlap = termOverlap(`${title} ${text}`, tokens);
    if (overlap < needed) continue;
    const excerpt = asCustomerSentence(excerptFrom(text));
    if (excerpt.length < 40) continue;
    const section = policySection(excerpt);
    ranked.push({
      faq: false,
      overlap,
      citation: {
        id: String(hit.id),
        title,
        source: section ? `${title} — ${section}` : friendlySourceLabel(String(hit.source), title),
        docCode: "",
        page: Number(hit.page),
        excerpt,
        score: hit.score,
      },
    });
  }

  ranked.sort((a, b) => b.overlap - a.overlap || Number(b.faq) - Number(a.faq) || b.citation.score - a.citation.score);
  const pool = ranked.some((item) => item.faq) ? ranked.filter((item) => item.faq) : ranked;
  const best = pool[0];
  if (!best) return [];

  const cap = tokens.length < 2 ? 1 : limit;
  const seen = new Set<string>();
  const citations: Citation[] = [];
  for (const item of pool) {
    if (item.overlap < best.overlap - 0.15) continue;
    if (item.citation.score < best.citation.score * 0.72 && item.overlap < best.overlap) continue;
    const key = `${item.citation.title}:${item.citation.excerpt.slice(0, 80)}`;
    if (seen.has(key)) continue;
    seen.add(key);
    citations.push(item.citation);
    if (citations.length >= cap) break;
  }
  return citations;
}

export function isLowConfidence(citations: Citation[]): boolean {
  return citations.length === 0;
}

export function buildFallbackAnswer(
  query: string,
  citations: Citation[],
): { answer: string; refused: boolean } {
  if (!contentTokens(query).length) {
    return { refused: false, answer: HELP };
  }

  if (isLowConfidence(citations)) {
    return { refused: true, answer: NOT_FOUND };
  }

  const parts: string[] = [];
  const seen = new Set<string>();
  for (const citation of citations.slice(0, 2)) {
    const body = asCustomerSentence(citation.excerpt);
    const key = body.toLowerCase();
    if (!body || seen.has(key)) continue;
    seen.add(key);
    parts.push(body);
  }
  return {
    refused: false,
    answer: `${parts.join("\n\n")}\n\nSource: ${citations[0].source}`,
  };
}
