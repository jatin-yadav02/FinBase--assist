import type { Metadata } from "next";
import { Fraunces, Plus_Jakarta_Sans } from "next/font/google";
import "./globals.css";

const display = Fraunces({
  variable: "--font-display",
  subsets: ["latin"],
  weight: ["500", "600", "700"],
});

const body = Plus_Jakarta_Sans({
  variable: "--font-body",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
});

export const metadata: Metadata = {
  title: "FinBase — Customer Support",
  description:
    "FinBase customer support. Ask about savings, payments, cards, deposits, loans, and KYC.",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html
      lang="en"
      className={`${display.variable} ${body.variable} h-full antialiased`}
      style={{ colorScheme: "light", background: "#F3F5EF" }}
    >
      <body
        className="min-h-full font-sans"
        style={{ background: "#F3F5EF", color: "#0A0A0A" }}
      >
        {children}
      </body>
    </html>
  );
}
