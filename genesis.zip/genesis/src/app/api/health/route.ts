import { NextResponse } from "next/server";
import { getChunks, getFaqs } from "@/lib/knowledge";
import { getOpenRouterApiKey, OPENROUTER_MODEL } from "@/lib/openrouter";

export async function GET() {
  return NextResponse.json({
    ok: true,
    chunks: getChunks().length,
    faqs: getFaqs().length,
    model: OPENROUTER_MODEL,
    openRouterConfigured: Boolean(getOpenRouterApiKey()),
  });
}
