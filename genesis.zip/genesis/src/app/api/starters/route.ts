import { NextResponse } from "next/server";
import { getStarterTopics } from "@/lib/knowledge";

export async function GET() {
  return NextResponse.json({ topics: getStarterTopics(6) });
}
