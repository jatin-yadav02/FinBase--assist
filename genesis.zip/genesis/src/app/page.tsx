import { ChatApp } from "@/components/chat-app";
import { getStarterTopics } from "@/lib/knowledge";

export default function Home() {
  return <ChatApp topics={getStarterTopics(6)} />;
}
