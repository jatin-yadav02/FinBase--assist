#!/usr/bin/env python3
"""Ingest FinBase policy PDFs into data/knowledge/{chunks,faqs}.json."""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path

from pypdf import PdfReader

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "assets" / "knowledge"
OUT = ROOT / "data" / "knowledge"

DOC_META = {
    "sample_1.pdf": {
        "title": "Fixed Deposits & Wealth Products",
        "code": "FB-POL-FDW-2026-V3",
        "category": "wealth",
    },
    "sample_2.pdf": {
        "title": "Payments, UPI & Refund Settlement",
        "code": "FB-SOP-PAY-2026-V4",
        "category": "payments",
    },
    "sample_3.pdf": {
        "title": "Credit Cards Handbook",
        "code": "FB-POL-CC-2026-V5",
        "category": "cards",
    },
    "sample_4.pdf": {
        "title": "Digital Savings Accounts",
        "code": "FB-POL-SAV-2026-V3",
        "category": "savings",
    },
    "sample_5.pdf": {
        "title": "Personal Loans Policy",
        "code": "FB-POL-PL-2026-V4",
        "category": "loans",
    },
    "sample_6.pdf": {
        "title": "KYC, Compliance & Security",
        "code": "FB-POL-KYC-SEC-2026-V5",
        "category": "kyc",
    },
}


def clean(text: str) -> str:
    text = text.replace("\x00", " ")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.replace("■", "₹").strip()


def chunk_text(text: str, size: int = 900, overlap: int = 150) -> list[str]:
    chunks: list[str] = []
    i = 0
    while i < len(text):
        end = min(len(text), i + size)
        if end < len(text):
            br = text.rfind("\n", i + size // 2, end)
            if br > i:
                end = br
        piece = text[i:end].strip()
        if piece:
            chunks.append(piece)
        if end >= len(text):
            break
        i = max(end - overlap, i + 1)
    return chunks


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    chunks = []
    faqs = []
    seen_faq: set[tuple[str, str]] = set()

    for pdf in sorted(SRC.glob("*.pdf")):
        meta = DOC_META.get(
            pdf.name,
            {"title": pdf.stem, "code": pdf.stem, "category": "general"},
        )
        reader = PdfReader(str(pdf))
        pages: list[str] = []
        for pi, page in enumerate(reader.pages):
            t = clean(page.extract_text() or "")
            pages.append(t)
            for ci, c in enumerate(chunk_text(t)):
                cid = hashlib.sha1(
                    f"{pdf.name}:{pi}:{ci}:{c[:40]}".encode()
                ).hexdigest()[:12]
                chunks.append(
                    {
                        "id": cid,
                        "source": pdf.name,
                        "title": meta["title"],
                        "docCode": meta["code"],
                        "category": meta["category"],
                        "page": pi + 1,
                        "text": c,
                    }
                )

        full = clean("\n".join(pages))
        for m in re.finditer(
            r"(Q\d{3}):\s*([^\n]+)\n(.*?)(?=\nQ\d{3}:|\Z)", full, re.S
        ):
            qid, q, a = m.group(1), m.group(2).strip(), clean(m.group(3))
            a = re.split(r"\nSection \d+:", a)[0].strip()
            a = re.sub(
                r"\s*[·•.]?\s*(Instrument Category:|Risk-o-meter Rating:|"
                r"Tax implication:|Verification reference:).*$",
                "",
                a,
                flags=re.I,
            )
            a = re.sub(r"\[Reference[^\]]*\]\.?", "", a)
            a = re.sub(r"Under Section \d+,?\s*", "", a)
            a = re.sub(r"\s+", " ", a).strip()
            q = re.sub(r"\s*\([^)]*\)\s*$", "", q).strip()
            key = (meta["category"], q.lower())
            if key in seen_faq or len(a) < 40:
                continue
            seen_faq.add(key)
            faqs.append(
                {
                    "id": f"{meta['category']}-{qid}",
                    "question": q,
                    "answer": a[:800],
                    "source": pdf.name,
                    "title": meta["title"],
                    "category": meta["category"],
                }
            )

    unique_faqs = []
    qseen: set[str] = set()
    for f in faqs:
        nq = re.sub(r"\W+", " ", f["question"].lower()).strip()
        if nq in qseen:
            continue
        qseen.add(nq)
        unique_faqs.append(f)

    (OUT / "chunks.json").write_text(
        json.dumps(chunks, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (OUT / "faqs.json").write_text(
        json.dumps(unique_faqs, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"Wrote {len(chunks)} chunks and {len(unique_faqs)} faqs to {OUT}")


if __name__ == "__main__":
    main()
