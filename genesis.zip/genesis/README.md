# FinBase Assist

Customer support chat for FinBase. Ask about savings, UPI, cards, FDs, loans, or KYC — answers come from the six policy PDFs in `assets/knowledge/`, not from the model inventing rates.

## Setup

Needs Node 20+.

```bash
npm install
cp .env.example .env.local
# add OPENROUTER_API_KEY (see below)
npm run dev
```

App: http://127.0.0.1:4317

Rebuild knowledge files after changing PDFs:

```bash
pip install pypdf
npm run ingest
```

That writes `data/knowledge/chunks.json` and `data/knowledge/faqs.json` (already committed: 751 chunks, 60 FAQs).

## Environment variables

| Variable | Required | What it does |
| --- | --- | --- |
| `OPENROUTER_API_KEY` | For LLM answers | OpenRouter key from [openrouter.ai/keys](https://openrouter.ai/keys). Put it in `.env.local`. |
| `OPENROUTER_MODEL` | No | Defaults to `z-ai/glm-5.3-flash`. |

Without the key the app still starts. Retrieval runs, and answers are cleaned policy excerpts (`retrieval-fallback`). With the key, GLM 5.3 Flash writes the reply from retrieved context.

`.env.example` is the template. Copy → `.env.local` (gitignored).

## RAG architecture

```
policy PDFs (assets/knowledge/)
        │
        ▼  scripts/ingest_knowledge.py (pypdf)
chunks.json + faqs.json  (committed under data/knowledge/)
        │
        ▼  MiniSearch BM25 at request time
top passages (+ FAQ hits)
        │
        ├─ low score (< 1.2) → refuse
        ├─ no API key        → cleaned excerpts
        └─ API key set       → OpenRouter GLM answers from CONTEXT only
```

1. Offline ingest chunks (~900 chars, overlap) and pulls Q&As already in the PDFs.
2. `src/lib/retrieve.ts` searches both indexes (FAQs boosted higher).
3. `src/lib/chat.ts` sends system prompt + CONTEXT to OpenRouter, then `src/lib/customer-copy.ts` strips corpus boilerplate before the UI sees it.

No separate vector database. No embedding model. Retrieval is lexical BM25 via MiniSearch over JSON loaded in-process.

## Model / retrieval details

| Piece | Choice |
| --- | --- |
| LLM | `z-ai/glm-5.3-flash` via OpenRouter (OpenAI-compatible SDK) |
| Retrieval | MiniSearch BM25 (in-memory over committed JSON) |
| Vector DB | None |
| Embeddings | None |

Temperature `0.2`. Prompt: use only CONTEXT, plain language, no invented fees/rates, no account actions.

## API

Next.js App Router handlers in `src/app/api/`.

### `POST /api/chat`

```json
{
  "message": "What is the senior citizen FD rate for 1 year?",
  "history": [
    { "role": "user", "content": "..." },
    { "role": "assistant", "content": "..." }
  ]
}
```

`history` optional (max 12). `message` max 2000 chars.

Response:

```json
{
  "answer": "...",
  "citations": [
    {
      "id": "...",
      "title": "Fixed Deposits & Wealth Products",
      "source": "Fixed Deposits & Wealth Products",
      "docCode": "",
      "page": 2,
      "excerpt": "...",
      "score": 4.2
    }
  ],
  "mode": "llm",
  "refused": false
}
```

`mode` is `"llm"` or `"retrieval-fallback"`. `refused` is true on low-confidence / out-of-scope. Citations are customer-facing (policy title + excerpt; corpus filenames / internal codes are cleared before response).

### `GET /api/health`

```json
{
  "ok": true,
  "chunks": 751,
  "faqs": 60,
  "model": "z-ai/glm-5.3-flash",
  "openRouterConfigured": false
}
```

### `GET /api/starters`

```json
{
  "topics": [
    { "label": "Savings balance", "prompt": "What is the minimum balance..." }
  ]
}
```

Six topic chips for the empty state.

## Repo layout

```
assets/knowledge/     source policy PDFs
data/knowledge/       prebuilt chunks + FAQs
scripts/              ingest_knowledge.py
src/app/api/          chat, health, starters
src/lib/              retrieve, OpenRouter, customer copy
src/components/       chat UI
```

## Notes

Cites policy titles (and page when present). Refuses when retrieval score is low. Does not perform account actions.
